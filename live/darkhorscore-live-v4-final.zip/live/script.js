const $ = (id) => document.getElementById(id);

const sampleData = {
  date: "2026/06/30",
  place: "名古屋",
  race: "11R",
  raceName: "上品ホワイトボードテスト",
  start: "15:30",
  deadline: "15:28",
  SAFE: "⑤ サンライズジパング",
  LONGSHOT: "⑪ ダークホース",
  "ジヨ": "② ジヨセレクト",
  safeMemo: "安定軸。展開が向けば崩れにくい。",
  longshotMemo: "人気薄でも一発あり。相手に入れたい。",
  jiyoMemo: "直感＋馬場読み。ライブ本命。",
  memo: "・良馬場想定\n・先行有利\n・締切前にオッズ確認"
};

function splitPick(value = "") {
  const text = String(value).trim();
  const m = text.match(/^([◎○▲△☆★]?\s*[0-9０-９①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱]+)\s*(.*)$/);
  if (!m) return { number: "◎", horse: text || "—" };
  return { number: m[1].replace(/\s/g, ""), horse: m[2] || "—" };
}

function setText(id, value, fallback = "—") {
  $(id).textContent = value == null || value === "" ? fallback : value;
}

function applyData(row) {
  const data = { ...sampleData, ...row };
  const safe = splitPick(data.SAFE || data.safe || data.safeHorse);
  const longshot = splitPick(data.LONGSHOT || data.longshot || data.longshotHorse);
  const jiyo = splitPick(data["ジヨ"] || data.jiyo || data.jiyoHorse);

  setText("date", data.date || data["日付"]);
  setText("place", data.place || data["競馬場"]);
  setText("race", data.race || data["レース"]);
  setText("raceName", data.raceName || data["レース名"]);
  setText("startTime", data.start || data["発走"]);
  setText("deadlineTime", data.deadline || data["締切"]);

  setText("safeNumber", safe.number);
  setText("safeHorse", safe.horse);
  setText("longshotNumber", longshot.number);
  setText("longshotHorse", longshot.horse);
  setText("jiyoNumber", jiyo.number);
  setText("jiyoHorse", jiyo.horse);

  setText("safeMemo", data.safeMemo || "安定軸として表示");
  setText("longshotMemo", data.longshotMemo || "穴候補として表示");
  setText("jiyoMemo", data.jiyoMemo || "ジヨの本命として表示");
  setText("mainMemo", data.memo || data["メモ"] || "");

  setText("updatedAt", `updated ${new Date().toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}`);
  $("board").classList.remove("fade");
  void $("board").offsetWidth;
  $("board").classList.add("fade");
}

async function fetchSheet() {
  const url = window.DARKHORSCORE_SHEET_API_URL;
  if (!url) {
    applyData(sampleData);
    return;
  }

  try {
    const res = await fetch(`${url}${url.includes("?") ? "&" : "?"}t=${Date.now()}`, { cache: "no-store" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    const row = Array.isArray(json) ? json[0] : (json.data || json.row || json);
    applyData(row || sampleData);
  } catch (e) {
    console.error(e);
    setText("updatedAt", "sheet error");
  }
}

function updateCountdown() {
  const dateText = $("date").textContent.replaceAll("/", "-");
  const deadline = $("deadlineTime").textContent;
  if (!/^\d{4}-\d{1,2}-\d{1,2}$/.test(dateText) || !/^\d{1,2}:\d{2}$/.test(deadline)) {
    $("countdown").textContent = "--:--";
    return;
  }
  const target = new Date(`${dateText}T${deadline}:00`);
  const diff = target - new Date();
  if (Number.isNaN(target.getTime())) return;
  if (diff <= 0) {
    $("countdownLabel").textContent = "受付終了";
    $("countdown").textContent = "CLOSED";
    return;
  }
  const m = Math.floor(diff / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  $("countdownLabel").textContent = "締切まで";
  $("countdown").textContent = `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

fetchSheet();
setInterval(fetchSheet, window.DARKHORSCORE_REFRESH_MS || 5000);
setInterval(updateCountdown, 1000);
