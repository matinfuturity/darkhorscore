// Google Apps Script のウェブアプリURLをここに入れる
// 例: window.DARKHORSCORE_SHEET_API_URL = "https://script.google.com/macros/s/xxxxx/exec";
window.DARKHORSCORE_SHEET_API_URL = "";

// 更新間隔。OBSなら 5000〜10000 がおすすめ
window.DARKHORSCORE_REFRESH_MS = 5000;
