// Google Apps Script 側のサンプル
// スプレッドシート1行目を見出し、2行目を表示データにする想定
function doGet() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const row = values[1];
  const data = {};
  headers.forEach((h, i) => data[h] = row[i]);

  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
