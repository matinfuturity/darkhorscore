# DARKHORSCORE LIVE v4

OBS用 1920×1080 固定のライブ画面です。

## GitHub Pagesへの入れ方

`live` フォルダの中身を GitHub の `/live` に上書きアップロードしてください。

## スプレッドシート連携

`config.js` のURLをApps ScriptのURLに変更します。

```js
window.DARKHORSCORE_SHEET_API_URL = "https://script.google.com/macros/s/xxxxx/exec";
```

## 対応見出し

- 日付 / date
- 競馬場 / place
- レース / race
- レース名 / raceName
- 発走 / start
- 締切 / deadline
- SAFE
- LONGSHOT
- ジヨ
- メモ / memo

SAFE、LONGSHOT、ジヨは `⑤ 馬名` の形がおすすめです。
