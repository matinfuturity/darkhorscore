const CONFIG = window.DARKHORSCORE_LIVE_CONFIG || {};

const demoData = {
  date: '6/30',
  course: '名古屋',
  race: '7R',
  raceName: 'DARKHORSCORE LIVE v4 テスト配信',
  postTime: '18:05',
  closeTime: '18:03',
  safe: '④ グレイスフルスター',
  longshot: '⑧ ミッドナイトランナー',
  jiyo: '② ホワイトボードキング',
  horseName: '',
  memo: '先行有利想定。SAFEは崩れにくさ重視、LONGSHOTは展開ハマり待ち。',
  safeMemo: '安定感重視',
  longshotMemo: '展開待ちの穴',
  jiyoMemo: 'ジヨ注目'
};

const $ = (id) => document.getElementById(id);

function setText(id, value, fallback = '--') {
  const el = $(id);
  if (!el) return;
  el.textContent = value || fallback;
}

function normalizeData(raw) {
  if (Array.isArray(raw)) raw = raw[0] || {};
  if (raw.data) raw = raw.data;

  return {
    date: raw.date || raw['日付'],
    course: raw.course || raw['競馬場'],
    race: raw.race || raw['レース'],
    raceName: raw.raceName || raw['レース名'],
    postTime: raw.postTime || raw['発走'],
    closeTime: raw.closeTime || raw['締切'],
    safe: raw.safe || raw['SAFE'],
    longshot: raw.longshot || raw['LONGSHOT'],
    jiyo: raw.jiyo || raw['ジヨ'],
    horseName: raw.horseName || raw['馬名'],
    memo: raw.memo || raw['メモ'],
    safeMemo: raw.safeMemo || raw['SAFEメモ'],
    longshotMemo: raw.longshotMemo || raw['LONGSHOTメモ'],
    jiyoMemo: raw.jiyoMemo || raw['ジヨメモ']
  };
}

function render(data) {
  const d = { ...demoData, ...data };
  setText('date', d.date);
  setText('course', d.course);
  setText('raceNo', d.race);
  setText('raceName', d.raceName);
  setText('postTime', d.postTime);
  setText('closeTime', d.closeTime);
  setText('safeHorse', d.safe || d.horseName);
  setText('longshotHorse', d.longshot);
  setText('jiyoHorse', d.jiyo);
  setText('mainMemo', d.memo);
  setText('safeMemo', d.safeMemo);
  setText('longshotMemo', d.longshotMemo);
  setText('jiyoMemo', d.jiyoMemo);
  updateCountdown(d.closeTime);
}

function updateClock() {
  const now = new Date();
  setText('clock', now.toLocaleTimeString('ja-JP', { hour12: false }));
}

function updateCountdown(closeTime) {
  if (!closeTime || !closeTime.includes(':')) {
    setText('countdown', '--:--');
    return;
  }

  const now = new Date();
  const [h, m] = closeTime.split(':').map(Number);
  const close = new Date(now);
  close.setHours(h, m, 0, 0);
  const diff = close - now;

  if (Number.isNaN(diff)) {
    setText('countdown', '--:--');
    return;
  }

  if (diff <= 0) {
    setText('countdown', '締切');
    document.body.classList.add('closed');
    return;
  }

  document.body.classList.remove('closed');
  const mm = String(Math.floor(diff / 60000)).padStart(2, '0');
  const ss = String(Math.floor((diff % 60000) / 1000)).padStart(2, '0');
  setText('countdown', `${mm}:${ss}`);
}

async function loadSheet() {
  const url = CONFIG.SHEET_API_URL;
  if (!url) {
    setText('connectionStatus', 'DEMO');
    if (CONFIG.DEMO_MODE_WHEN_EMPTY !== false) render(demoData);
    return;
  }

  try {
    const res = await fetch(`${url}${url.includes('?') ? '&' : '?'}t=${Date.now()}`, { cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    render(normalizeData(json));
    setText('connectionStatus', 'LIVE');
    $('connectionStatus')?.classList.add('live');
  } catch (e) {
    console.error(e);
    setText('connectionStatus', 'ERROR');
    $('connectionStatus')?.classList.remove('live');
  }
}

updateClock();
setInterval(updateClock, 1000);
loadSheet();
setInterval(loadSheet, CONFIG.REFRESH_MS || 10000);
