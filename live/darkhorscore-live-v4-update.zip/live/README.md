# DARKHORSCORE LIVE v4

OBS用の1920×1080固定ライブボードです。
机の上のモニター風デザイン、ホワイトボードメイン、Googleスプレッドシート連携対応。

## 使い方

1. この `live` フォルダ内のファイルをGitHub Pagesの `/live` に上書きアップロード
2. `config.js` を開く
3. `SHEET_API_URL` にGoogle Apps ScriptのWebアプリURLを入れる
4. `/live/` を開く

## スプレッドシート見出し

1行目に以下を入れてください。

日付, 競馬場, レース, レース名, 発走, 締切, SAFE, LONGSHOT, ジヨ, 馬名, メモ

## 更新間隔

デフォルトは10秒ごとです。`config.js` の `REFRESH_MS` で変更できます。
