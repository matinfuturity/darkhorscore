// DARKHORSCORE LIVE v4 config
// Google Apps ScriptのWebアプリURLをここに入れる。
// 例: https://script.google.com/macros/s/xxxxx/exec
window.DARKHORSCORE_LIVE_CONFIG = {
  SHEET_API_URL: '',
  REFRESH_MS: 10000,
  DEMO_MODE_WHEN_EMPTY: true
};
