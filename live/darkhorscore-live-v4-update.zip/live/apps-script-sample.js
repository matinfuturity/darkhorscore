// Google Apps Script サンプル
// 1行目を見出し、2行目を表示データとして返す版。
// 見出し例: 日付,競馬場,レース,レース名,発走,締切,SAFE,LONGSHOT,ジヨ,馬名,メモ
function doGet() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
  const values = sheet.getDataRange().getDisplayValues();
  const headers = values[0];
  const row = values[1];
  const data = {};

  headers.forEach((key, i) => {
    data[key] = row[i] || '';
  });

  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
